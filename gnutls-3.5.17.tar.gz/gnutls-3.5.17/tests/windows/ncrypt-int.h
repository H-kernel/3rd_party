#define assert_int_nequal(x,y) assert((x)==(y))
